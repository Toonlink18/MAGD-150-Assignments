function setup() {
  createCanvas(200, 200);
}

function draw() {
  background(90);
  
  rect(75,110,50,200);
  fill(255);

  noStroke();
rect(20, 20, 60, 60);
  fill(255);
  
  noStroke();
rect(120, 20, 60, 60);
  fill(0);
  
  ellipseMode(RADIUS);
fill(10);
ellipse(115, 155, 5, 5); // Outer white ellipse
ellipseMode(CENTER);
fill(255);
ellipse(115, 155, 4, 4);
  
  
}