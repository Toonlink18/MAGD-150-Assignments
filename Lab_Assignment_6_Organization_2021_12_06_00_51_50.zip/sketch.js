//Just wanted to give a quick thanks to some of my buddies on discord for helping me with this. There is no way I would have been able to make this without them.

var gameState = "Intro";

var rectX = 200;
var rectY = 200;

var DTB = 0.0;

var Points = 0;

function setup() {
  createCanvas(400, 400);
  
	textAlign(CENTER);
}

function draw() {
  background(160,0,220);
	if(gameState == "Intro"){
		Intro();
	}
	if(gameState == "GameStarted"){
		gameStarted();
	}
	if(gameState == "GameEnd"){
		gameEnd();
	}
}

//Starts the game using the gameState "Intro", when the mouse is clicked it starts the function gameStarted.
function Intro(){
	text("Current Points: " + Points,width/2,20);
	text("Timer(1000 = Game End): " + frameCount, width/2,40);
	text("Click Anywhere to Begin", width/2,height/2);
 
  //Used scale, translate, and rotate here since it would screw up the code for the other rectangle and I didn't have enough time to fix it
  push();
  fill(255);
  scale(1.5);
  rotate(PI/5.0);
  translate(30,40);
  rect(25,5,25);
  pop();
  
  if(mouseIsPressed){
		gameState = "GameStarted";
	}
} 
//gameStarted is where the action takes place, it counts your points, has a timer that uses framerate to track your current time and makes the rectangle buttons appear randomly around the screen.
function gameStarted(){
	background(0,255,0);
  //DTB means distance to button(just shortened it since I felt it was too long) uses rectX and rectY along with mouseX and mouseY to calculate the exact distance of the cursor to the middle of the rectangle/button
  DTB = dist(rectX,rectY,mouseX,mouseY);

	text("Current Points: " + Points,width/2,20);
	text("Timer(1000 = Game End): " + frameCount, width/2,40);
  
  push();
     fill(255,140,220);
	rect(rectX,rectY,50,50);	
  pop();
		
	if(DTB <45){  
		rectX = random(width);
		rectY = random(height);
		Points += 1;
	}
	if(frameCount>=1000){  	
		gameState = "GameEnd";
	}
}
//Appears after 1000 frames, has your total score and allows you to begin a new game if you click which takes you to the gameState "Intro"(Which isn't working and I can't figure out why)
function gameEnd(){
	background(255,0,0);
	text("End of Game Score: " + Points,width/2,20);
	text("Timer(1000 = Game End): " + frameCount, width/2,40);
	text("Game End", width/2,100);
	text("Click here to attempt again", width/2,200);
	
  if(mouseIsPressed){
		gameState = "Intro";
	}
} 


