function setup() {
  createCanvas(450, 400);
}

function draw() {
  background(0);
  
  push();
  fill(230, 14, 164)
  quad(40, 30, 50, 40, 40, 50, 30, 40);
  pop();
  
  push();
  fill(240,161,237)
  quad(400, 20, 420, 40, 400, 60, 380, 40);
  pop();
  
  
  push();
  noStroke()
  fill(255,255,0);
  triangle(20, 180, 230, 0, 435, 180);
  pop();
  
  push();
  noStroke()
  fill(255,255,0);
  triangle(20, 180, 230, 385, 435, 180);
  pop();
  
  push();
  noStroke()
  colorMode(RGB, 255, 255, 255, 1);
  fill(255, 0, 0);
  beginShape();
  vertex(120, 80);
  vertex(340, 80);
  vertex(340, 300);
  vertex(120, 300);
  endShape(CLOSE);
  pop();

  push();
  noStroke()
  beginShape();
  colorMode(HSB, 360, 100, 100, 100);
  fill(200, 200, 200);
  vertex(140, 100);
  vertex(320, 100);
  vertex(320, 280);
  vertex(140, 280);
  endShape(CLOSE);
  pop();

  push();
  noStroke()
  beginShape();
  colorMode(RGB, 255, 255, 255, 1);
  fill("#AF13F2");
  vertex(160, 120);
  vertex(300, 120);
  vertex(300, 260);
  vertex(160, 260);
  endShape(CLOSE);
  pop();
  
}
