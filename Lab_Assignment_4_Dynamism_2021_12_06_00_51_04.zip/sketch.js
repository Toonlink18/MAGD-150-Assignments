let x = 'Pizza';
let z = 'Time';

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(255);
   noStroke();
  
  fill(117,86,45);
  rect(8,20,380,38);
  
  fill(255,204,7,100);
  triangle(10, 22, 390, 20, 200, 390);
  
//change in color represents different toppings, ex. ham
  fill(175,20,0,69);
  if (mouseIsPressed) {
    ellipse(90, 90, 50, 50);
  } else {
    fill(255,0,0);
    ellipse(90, 90, 50, 50);
  }
  
  fill(175,20,0,69);
  if (mouseIsPressed) {
    ellipse(140,160,50,50);
  } else {
    fill(255,0,0);
    ellipse(140,160,50,50);
  } 
  
  fill(175,20,0,69);
  if (mouseIsPressed) {
    ellipse(180, 270, 50, 50);
  } else {
    fill(255,0,0);
    ellipse(180, 270, 50, 50);
  }
  
   if (keyIsPressed === true) {
    fill(175,20,0,69);
  } else {
    fill(255,0,0);
  }
  ellipse(310, 110, 50, 50);
  
  if (keyIsPressed === true) {
    fill(175,20,0,69);
  } else {
    fill(255,0,0);
  }
  ellipse(220, 90, 50, 50);
  
  if (keyIsPressed === true) {
    fill(175,20,0,69);
  } else {
    fill(255,0,0);
  }
  ellipse(260, 200, 50, 50);
  
  fill(0);
  textSize(40);
  text(x,mouseX,35);
  
  
  fill(0);
  textSize(40);
  text(z,mouseX,390);
  
  //Only used 1 as the input due to lag if I went any higher
  let chez = 1;
while (chez > 0) {
  chez = chez - 1;
  print(chez);
  
  let cheez = 4;
 if (cheez > 2) {
    cheez = cheez - 3;
  } else{
    print(cheez);  
    }
}
  
}
