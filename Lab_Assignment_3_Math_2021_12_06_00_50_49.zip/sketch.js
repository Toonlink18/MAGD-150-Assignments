function setup() {
  createCanvas(400, 400);
  
  let x = 10
  
  let y = 0.5 
  
  print('The value of X + Y is ' + x+y);
  print('The value of X * X is ' + x*y);
  print('The value of X is smaller than Y ' + x<y);
  print('The value of X divided by Y is ' + x/y);

  
  let numArray = [2, 4, 6, 8, 10, 12];
  
  print(max(numArray));
  print(min(numArray));
  
   frameRate(60);
  textSize(30);
  textAlign(CENTER);
  
}

function draw() {
  background(0);
  
  fill(255,80,255)
  ellipse(100,100,300,300)
  
   fill(180,255,200)
  ellipse(300,300,300,300)
  
   fill(200,200,255)
  ellipse(200,200,300,300)
  
  fill(0)
   text(frameCount, width / 2, height / 2);
  
  let boundaryL = 100;
  let boundaryR = 300;
  
   let tr = constrain(mouseX, boundaryL, boundaryR);
  
  line(boundaryL, 0, boundaryL, height);
  line(boundaryR, 0, boundaryR, height);
  
    noStroke()
  fill(255,0,0)
   ellipse(tr, mouseY, 60, 60, 60);
  
   noStroke()
  fill(0,255,0)
   ellipse(tr, mouseY, 50, 50, 50);
  
  noStroke()
  fill(0,0,255)
   ellipse(tr, mouseY, 40, 40, 40);
  
  noStroke()
  fill(100,200,30)
   ellipse(mouseY, 40, 40, 40);
  
   noStroke()
  fill(200,70,240)
   ellipse(mouseX, 40, 40, 40);
}